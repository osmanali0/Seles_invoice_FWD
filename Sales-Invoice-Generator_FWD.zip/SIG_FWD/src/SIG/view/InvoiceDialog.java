
package SIG.view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author othman
 */
public class InvoiceDialog extends JDialog {
    private JTextField custNameField;
    private JTextField invDateField;
    private JLabel custNameLbl;
    private JLabel invDateLbl;
    private JButton save;
    private JButton DontSaveNewInvoice;

    public InvoiceDialog(InvoiceFrame frame) {
     
        invDateLbl = new JLabel("    Invoice Date:");
        invDateField = new JTextField(15);
        custNameLbl = new JLabel("    New Customer Name:");
        custNameField = new JTextField(15);
        save = new JButton("save Customer");
        DontSaveNewInvoice = new JButton("Cancel");
        
        save.setActionCommand("createInvoiceOK");
        DontSaveNewInvoice.setActionCommand("createInvoiceCancel");
        
        save.addActionListener(frame.getController());
        DontSaveNewInvoice.addActionListener(frame.getController());
        setLayout(new GridLayout(3, 2));
        
        add(invDateLbl);
        add(invDateField);
        add(custNameLbl);
        add(custNameField);
        add(save);
        add(DontSaveNewInvoice);

        pack();
        
    }

    public JTextField getCustomer_NameField() {
        return custNameField;
    }

    public JTextField getInvoice_DateField() {
        return invDateField;
    }
    
}
